=== Media Search Plus ===

Contributors: PhilLehmann
Tags: media library, media, attachment
Requires at least: 3.5
Tested up to: 6.1
Stable tag: 0.8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Search through all fields in Media Library to actually find something.

== Description ==

This plugin is made for:

* Search through all fields in Media Library, including: ID, title, caption, alternative text and description.
* Search Taxonomies for Media, include the name, slug and description fields.
* Search media file name.
* Use shortcode `[msp-search-form]` to insert a media search form in posts and template files. It will search for media by all fields mentioned above.

== Installation ==

= Using The WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Search for 'media-search-plus'
3. Click 'Install Now'
4. Activate the plugin on the Plugin dashboard

= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `media-search-plus.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard

= Using FTP =

1. Download `media-search-plus.zip`
2. Extract the `media-search` directory to your computer
3. Upload the `media-search` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard

== Frequently Asked Questions ==

= How to link media to the file itself rather than the attachment page in media search results page? =

Please add the following code to the `functions.php` in your theme:

	function my_get_attachment_url( $url, $post_id ) {

		$url = wp_get_attachment_url( $post_id );

		return $url;
	}
	add_filter( 'msp_get_attachment_url', 'my_get_attachment_url', 10, 2 );

== Screenshots ==

1. Demo search on the Media Library screen.
2. Demo search on the Insert Media - Media Library screen.

== Changelog ==

= 0.8.2 =
* Forked by PhilLehmann (original author so far 1fixdotio - http://1fix.io)
* Made compatible with WordPress 6.1
* Renamed shortcode `[mse-search-form]` to `[msp-search-form]`
* Renamed filter `mse_get_attachment_url` to `msp_get_attachment_url`
* Removed clutter in the code

= 0.8.1 =
* Fix PHP notices and updated the "Tested up to" field.

= 0.8.0 =
* Supporting MIME type and date filters when searching in the Media Library. Thanks to [@jedifunk](https://wordpress.org/support/topic/results-filters) for spotting this bug.

= 0.7.3 =
* Fix PHP warnings. Thanks to [@DavidOn3](https://wordpress.org/support/topic/warning-message-in-search-result-page).

= 0.7.2 =
* Bug fix: Make the search work with WPML Media - All languages.
* Filter the search form if it's on the media search results page.
* Make the images clickable in the search results. Can be disabled by setting the filter `mse_is_image_clickable` to `false`.

= 0.7.1 =
* Bug fix: Remove duplicate search results when WPML plugin is activated, THE RIGHT WAY.

= 0.7.0 =
* Remove duplicate search results when WPML plugin is activated. Props [@joseluiscruz](https://wordpress.org/support/topic/minor-conflict-with-wpml-media-plugin).

= 0.6.1 =
* Security update: use `$wpdb->prepare` to process SQL statements. Thanks to [@daxelrod](https://profiles.wordpress.org/daxelrod/) for this.

= 0.6.0 =
* Add ID to search fields.
* Modify the clauses with `posts_clauses` filter.

= 0.5.4 =
* Add filter `mse_get_attachment_url` to modify the attachment URLs in the media search results.

= 0.5.3 =
* Bug fix: Filtered excerpt should be returned, not echoed.

= 0.5.2 =
* Display thumbnails in the media search results.

= 0.5 =
* Use shortcode `[mse-search-form]` to insert a media search form in posts, which only searches for media files (through all fields).

= 0.4 =
* Search media file name.

= 0.3 =
* If there are Taxonomies for Media, search the name, slug and description fields.

= 0.2.1 =
* Add DISTINCT statement to SQL when query media in the "Insert Media" screen

= 0.2.0 =
* The first version